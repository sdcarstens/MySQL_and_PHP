<?php require_once('../../../private/initialize.php'); ?>

<?php $page_title = 'Subjects'; ?>
<?php include(SHARED_PATH . '/staff_header.php'); ?>

<div id="content">
</div>

<?php include(SHARED_PATH . '/staff_footer.php'); ?>
