<?php require_once('../../private/initialize.php'); ?>

<?php include('../../private/shared/staff_header.php'); ?>

<div id="content">
</div>

<?php include('../../private/shared/staff_footer.php'); ?>
